### What is journ.py?
Short and sweet? journ.py is a command line journal written in Python. journ.py is completely run in your terminal. To use it after installing, just type `journ` in your terminal, and hit enter. If it is the first time you are running it - journ.py will greet you, and show you where your journal file is going to be. Which will be your home directory.

Currently journ.py only uses the file journ.txt that it creates the first time you run it. In the future I want to add the ability to choose where you want your file, and what you want to name it.

Every run after the first will go straight to the `>` prompt where you can begin typing a new entry. Each entry is added to the end of your journal file, along with the date and time of entry.
