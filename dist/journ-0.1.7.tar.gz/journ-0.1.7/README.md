### ///What is journ?
Short and sweet? journ is a command line journal written in Python. journ is completely run in your terminal. To use it after installing, just type `journ` in your terminal, and hit enter. Currently journ only uses the file journ.txt that it creates the first time you run it. In the future I want to add the ability to choose where you want your file, and what you want to name it. journ will append each new entry to the bottom of your journal file, along with the date and time the entry was created. 

### ///Changelog
You can view the [changelog](https://github.com/ronbecker/journ/blob/master/CHANGELOG.md) on Github.
